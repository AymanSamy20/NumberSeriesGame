package com.example.numberseriesgame;

public class Question {
    private String [][] date;
    private int hiddenNumber;
    public Question(String [][] date,int hiddenNumber){
        this.date = date;
        this.hiddenNumber = hiddenNumber;
    }

    public String[][] getDate() {
        return date;
    }

    public void setDate(String[][] date) {
        this.date = date;
    }

    public int getHiddenNumber() {
        return hiddenNumber;
    }

    public void setHiddenNumber(int hiddenNumber) {
        this.hiddenNumber = hiddenNumber;
    }
}
