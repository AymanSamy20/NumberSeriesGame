package com.example.numberseriesgame.adapters;


import static java.lang.String.valueOf;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.numberseriesgame.Game;
import com.example.numberseriesgame.R;

import java.util.ArrayList;


public class CustomAdapter extends ArrayAdapter<Game> {
    private ArrayList<Game> games;
    private final Activity context;
    public CustomAdapter(Activity context,ArrayList<Game> games ) {
        super(context, R.layout.my_row, games);
        // TODO Auto-generated constructor stub
        this.games=games;
        this.context=context;
    }

    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.my_row, null,true);

        TextView name = (TextView) rowView.findViewById(R.id.tv_FullName);
        TextView score = (TextView) rowView.findViewById(R.id.tv_Score);
        TextView date = (TextView) rowView.findViewById(R.id.tv_Time);
        date.setText(games.get(position).getName());
        score.setText(valueOf(games.get(position).getScore()));
        name.setText(games.get(position).getDate());
//

        return rowView;

    };
}