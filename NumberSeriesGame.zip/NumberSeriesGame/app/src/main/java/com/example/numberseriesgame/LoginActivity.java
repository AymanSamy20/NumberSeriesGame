package com.example.numberseriesgame;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.media.MediaParser;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.cast.framework.media.ImagePicker;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.IOException;

import de.hdodenhof.circleimageview.CircleImageView;

public class LoginActivity extends AppCompatActivity {
    MediaPlayer player;
    Button login;
    EditText uesr,pass;
    SharedPreferences sharedPreferences;
    CheckBox login_checkBox;
    private static final String Key_sharedPreferences = "Mypraf";
    private static final String Key_username = "Username";
    private static final String Key_password = "Password";




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();
//        check if is already loged in
        sharedPreferences = getSharedPreferences(Key_sharedPreferences, MODE_PRIVATE);
        String name = sharedPreferences.getString(Key_username, null);
        Log.wtf("@@", "-->"+name);

        if (name != null) {
            Intent gameIntent =new Intent(this,GameActivity.class);
            startActivity(gameIntent);

        }else {
            Log.wtf("@@", "-->"+name);
        }
        uesr = findViewById(R.id.login_et_User_name);
        pass = findViewById(R.id.login_et_Password);
        login_checkBox = (CheckBox) findViewById(R.id.login_checkBox);
        sharedPreferences = getSharedPreferences(Key_sharedPreferences,MODE_PRIVATE);
        String username = sharedPreferences.getString(Key_username,null);
        String password = sharedPreferences.getString(Key_password,null);
        if (username != null||password != null){
            pass.setText(password);

        }
            uesr.setText(username);

    }
    public void  btn_login(View v){

        if (uesr.getText() != null && pass.getText() != null){
            if(login_checkBox.isChecked()){
                SharedPreferences.Editor editor =sharedPreferences.edit();
                editor.apply();
                Log.wtf("@@", "is selected");
            }else{
                Log.wtf("@@", "not selected");
            }
            Toast.makeText(LoginActivity.this, "log out successfully", Toast.LENGTH_SHORT).show();
            finish();

            Intent intent  = new Intent(LoginActivity.this,GameActivity.class);
            startActivity(intent);
            Click();
        }else{
            Toast.makeText(this, "please", Toast.LENGTH_SHORT).show();
        }

    }


    public void btn_Register(View view) {
        Intent intent = new Intent(LoginActivity.this,RegisterActivity.class);
        startActivity(intent);
        Click();
    }
    private  void Click(){
        if (player==null){
            player = MediaPlayer.create(getBaseContext(),R.raw.button);
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    stopplayer();
                }
            });
        }
        player.start();
    }
    private void  stopplayer(){
        if (player !=null){
            player.release();
            player = null;

        }
    }

}