package com.example.numberseriesgame;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.numberseriesgame.adapters.CustomAdapter;


import java.util.ArrayList;

public class Allgameslist extends AppCompatActivity {
    ImageView empty_imageview;
    TextView no_data;
    DatabaseHelper myDB;
    ArrayList<String> text_Score, text_FullName, text_Time;
    ListView list;
     
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_allgameslist);
        getSupportActionBar().hide();
        empty_imageview = findViewById(R.id.empty_imageview);
        no_data = findViewById(R.id.no_data);

        myDB = new DatabaseHelper(Allgameslist.this);
        ArrayList<Game> games = new ArrayList<Game>();
        

        games=myDB.readCourses();


         CustomAdapter adapter=new CustomAdapter(this, games);
        list=(ListView)findViewById(R.id.listView);
        list.setAdapter(adapter);


    }


}