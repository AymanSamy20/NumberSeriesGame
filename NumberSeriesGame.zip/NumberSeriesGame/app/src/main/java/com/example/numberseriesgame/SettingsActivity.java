package com.example.numberseriesgame;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class SettingsActivity extends AppCompatActivity {
    AlertDialog alertDialog;
    MediaPlayer player;
    Button change_password,all_game,change_language,game_history,last_game;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        getSupportActionBar().hide();
        change_password = findViewById(R.id.setting_et_change_password);
        all_game = findViewById(R.id.setting_et_all_games);
        change_language = findViewById(R.id.setting_et_change_language);
        last_game = findViewById(R.id.setting_et_last_game);
        game_history = findViewById(R.id.setting_et_game_history);


        all_game.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent all_game = new Intent(SettingsActivity.this,Allgameslist.class);
                startActivity(all_game);
             Click();

            }
        });
        last_game.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseHelper databaseHelper = new DatabaseHelper(SettingsActivity.this);
                ArrayList<Game>games = (ArrayList<Game>) databaseHelper.readAllData();
                String ss = "";
                for (Game I:games){
                    ss = I.getDate();
                }
                if (ss.equals("")){
                    Toast.makeText(SettingsActivity.this, "لم تلعب العاب من قبل", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(SettingsActivity.this, "اخر لعبة بتاريخ"+ss, Toast.LENGTH_SHORT).show();
                }

            }
        });


        change_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent change_password = new Intent(SettingsActivity.this,ChangePassword.class);
                startActivity(change_password);
               Click();
            }
        });
        change_language.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

         Intent  language = new Intent(SettingsActivity.this,Change_language.class);
         startActivity(language);

                }
        });




        game_history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmDialog();
                Click();
            }
            
            });
        }
        void confirmDialog(){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Delete All?");
            builder.setMessage("Are you sure you want to delete all Data?");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    DatabaseHelper myDB = new DatabaseHelper(SettingsActivity.this);
                    myDB.deleteAllData();
                    Click();
                    //Refresh Activity
                    Intent intent = new Intent(SettingsActivity.this, GameActivity.class);
                    startActivity(intent);
                    finish();
                }
            });
            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                }
            });
            builder.create().show();


    }
    private  void Click(){
        if (player==null){
            player = MediaPlayer.create(getBaseContext(),R.raw.button);
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    stopplayer();
                }
            });
        }
        player.start();
    }
    private void  stopplayer(){
        if (player !=null){
            player.release();
            player = null;

        }
    }







}