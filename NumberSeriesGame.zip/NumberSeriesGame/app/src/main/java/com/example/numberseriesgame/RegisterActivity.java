package com.example.numberseriesgame;

import static java.security.AccessController.getContext;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import com.google.android.gms.auth.api.signin.internal.Storage;
import com.google.android.gms.cast.framework.media.ImagePicker;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.InputMismatchException;

import de.hdodenhof.circleimageview.CircleImageView;

public class RegisterActivity extends AppCompatActivity {
    MediaPlayer player;
    SharedPreferences sharedPreferences;
    private static final String Key_sharedPreferences = "Mypraf";
    private static final String Key_username = "Username";
    private static final String Key_password = "Password";
    private static final String Key_Name = "Name";
    private static final String Key_Age = "Age";
    private CircleImageView profileImage;
    private AutoCompleteTextView Register_et_Country;
    Button btn_Save;
    EditText dateformat;

    Calendar C;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        getSupportActionBar().hide();
        profileImage = (CircleImageView) findViewById(R.id.Register_image_view);
        Register_et_Country = findViewById(R.id.Register_et_Country);
        dateformat = findViewById(R.id.Register_et_Birthdate);
        EditText Full_name = (EditText) findViewById(R.id.Register_Fullname);
        btn_Save = findViewById(R.id.Register_btn_save);
        EditText Username = (EditText) findViewById(R.id.Register_et_User_name);
        EditText Password = (EditText) findViewById(R.id.Register_et_password);




//        if (name != null) {
//            Log.wtf("@@", "-->"+name);
//
//        }else {
//            Intent gameIntent =new Intent(this,GameActivity.class);
//            startActivity(gameIntent);
//        }
//


        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.spinner_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Register_et_Country.setAdapter(adapter);


        dateformat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Click();
                final Calendar C = Calendar.getInstance();
                int mYear = C.get(Calendar.YEAR);
                int mMonth = C.get(Calendar.MONTH);
                int mDay = C.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog dateDialog = new DatePickerDialog(view.getContext(), datePickerListener, mYear, mMonth, mDay);
                dateDialog.getDatePicker().setMaxDate(new Date().getTime());
                dateDialog.show();
            }
        });

        sharedPreferences = this.getSharedPreferences(Key_sharedPreferences, MODE_PRIVATE);
        String name = sharedPreferences.getString(Key_username, null);
        Log.wtf("@@", "-->" + name);

        btn_Save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString(Key_username, Username.getText().toString());
                editor.putString(Key_password, Password.getText().toString());
                editor.putString(Key_Name,Full_name .getText().toString());
                editor.putString("Age", Integer.toString(calculateAge(C.getTimeInMillis())));
                editor.apply();
                Intent intent = new Intent(RegisterActivity.this, GameActivity.class);
                startActivity(intent);
               Click();
            }
        });
        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Click();
                AlertDialog.Builder builder = new AlertDialog.Builder(RegisterActivity.this);
                builder.setTitle("اختيار صورة").setMessage("اخنر طريقة اختيار الصورة")
                        .setPositiveButton("معرض الصور", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                arl1.launch("image/*");
                            }
                        }).setNegativeButton("الكاميرا", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        arl2.launch(null);
                    }
                }).setNeutralButton("الغاء", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();

                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });




    }

    private void  stopplayer(){
        if (player !=null){
            player.release();
            player = null;

        }
    }


    ActivityResultLauncher<String>arl1 = registerForActivityResult(new ActivityResultContracts.GetContent(), new ActivityResultCallback<Uri>() {
        @Override
        public void onActivityResult(Uri result) {
       profileImage.setImageURI(result);
        }
    });
    ActivityResultLauncher<Void>arl2 = registerForActivityResult(new ActivityResultContracts.TakePicturePreview(), new ActivityResultCallback<Bitmap>() {
        @Override
        public void onActivityResult(Bitmap result) {
            profileImage.setImageBitmap(result);
        }
    });

    private DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker datePicker, int year, int month, int day) {
            C = Calendar.getInstance();
            C.set(Calendar.YEAR, year);
            C.set(Calendar.MONTH, month);
            C.set(Calendar.DAY_OF_MONTH, day);
            String format = new SimpleDateFormat("dd MMM yyyy").format(C.getTime());
            dateformat.setText(format);





        }
    };
    private  void Click(){
        if (player==null){
            player = MediaPlayer.create(getBaseContext(),R.raw.button);
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    stopplayer();
                }
            });
        }
        player.start();
    }


    int calculateAge(long date) {
        Calendar dob = Calendar.getInstance();
        dob.setTimeInMillis(date);
        Calendar today = Calendar.getInstance();
        int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);
        if (today.get(Calendar.DAY_OF_MONTH) < dob.get(Calendar.DAY_OF_MONTH)) {
            age--;
        }
        return age;
    }


}
