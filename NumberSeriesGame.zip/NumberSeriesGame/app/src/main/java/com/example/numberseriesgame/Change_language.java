package com.example.numberseriesgame;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.Locale;

public class Change_language extends AppCompatActivity {
    Button English,Arabic;
    MediaPlayer player;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_language);
        English=findViewById(R.id.English);
        Arabic=findViewById(R.id.Arabic);
        English.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setLocale(Change_language.this,"en");
                Intent i = new Intent(Change_language.this,GameActivity.class);
                startActivity(i);
                Click();




            }
        });
        Arabic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setLocale( Change_language.this,"ar");
                Intent a= new Intent(Change_language.this,GameActivity.class);
                startActivity(a);
                Click();
            }
        });

    }
    public static void setLocale(Activity activity, String languageCode) {
        Locale locale = new Locale(languageCode);
        Locale.setDefault(locale);
        Resources resources = activity.getResources();
        Configuration config = resources.getConfiguration();
        config.setLocale(locale);
        resources.updateConfiguration(config, resources.getDisplayMetrics());
    }
    private  void Click(){
        if (player==null){
            player = MediaPlayer.create(getBaseContext(),R.raw.button);
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    stopplayer();
                }
            });
        }
        player.start();
    }
    private void stopplayer() {
        if (player != null) {
            player.release();
            player = null;

        }
    }
}