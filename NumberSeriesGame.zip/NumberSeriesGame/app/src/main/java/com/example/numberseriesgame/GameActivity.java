package com.example.numberseriesgame;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import com.example.numberseriesgame.databinding.ActivityGameBinding;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class GameActivity extends AppCompatActivity {
    ActivityGameBinding binding;
    long time;
    DatabaseHelper myDB;
    SharedPreferences sharedPreferences;
    MediaPlayer player;
    private static final String Key_sharedPreferences = "Mypraf";
    private static final String Key_username = "Username";
    private static final String Key_password = "Password";
    private static final String Key_Name = "Name";
    private static final String Key_Age = "Age";
    TextView score;
    EditText login_et_check;
    String answer;
    Util newUril = new Util();
    Question i = Util.generteQuestion();
    int incrementScore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        myDB = new DatabaseHelper(this);
        incrementScore = 0;
        sharedPreferences = getSharedPreferences(Key_sharedPreferences, MODE_PRIVATE);
        String name = sharedPreferences.getString(Key_Name, null);
        String Age = sharedPreferences.getString(Key_Age, null);
        DateFormat df = new SimpleDateFormat("EEE, d MMM yyyy, HH:mm");
        String date = df.format(Calendar.getInstance().getTime());
        Log.wtf("@@", "time: " + date);
        binding = ActivityGameBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.gameNameAge.setText(name + "[" + Age + "]");
        fillBoxes();
        Log.wtf("@@", "_> " + i.getHiddenNumber());
        binding.loginBtnCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                answer = binding.loginEtCheck.getText().toString();
                if (answer.equals(String.valueOf(i.getHiddenNumber()))) {
                    Win();
                    binding.loginEtCheck.setText("");
                    binding.gameScore.setText(String.valueOf(incrementScore += 5));
                    Log.wtf("@@", "_> " + i.getHiddenNumber() + ">>+" + answer);
                    View ture = getLayoutInflater().inflate(R.layout.answer_true, null);
                    Toast toast = new Toast(getBaseContext());
                    toast.setView(ture);
                    toast.setDuration(Toast.LENGTH_LONG);
                    toast.show();
                    fillBoxes();
                } else {
                    Wrong();
                    Log.wtf("@@", "_> " + i.getHiddenNumber() + ">>+" + answer);
                    login_et_check.setText("");
                    score.setText(String.valueOf(incrementScore));
                    View Error = getLayoutInflater().inflate(R.layout.answer_error, null);
                    Toast toast = new Toast(getBaseContext());
                    toast.setView(Error);
                    toast.setDuration(Toast.LENGTH_LONG);
                    toast.show();
                }
                Click();
            }
        });
        binding.gameBtnNewgame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fillBoxes();
                Click();
                myDB.addGame(date, name, incrementScore);
                Log.wtf("@@", "_> " + i.getHiddenNumber());
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.game_menu_item1:
                Click();
                Intent intent = new Intent(getApplicationContext(), SettingsActivity.class);
                startActivity(intent);
                return true;
            case R.id.game_menu_item2:
                Click();
                sharedPreferences = this.getSharedPreferences(Key_sharedPreferences, MODE_PRIVATE);
                sharedPreferences.edit().remove(Key_username).apply();
                sharedPreferences.edit().remove(Key_password).apply();
                sharedPreferences.edit().remove(Key_Name).apply();
                sharedPreferences.edit().remove(Key_Age).apply();
                Intent Remove = new Intent(GameActivity.this, LoginActivity.class);
                startActivity(Remove);
                return true;
            case R.id.game_menu_item3:
                onBackPressed();
                Click();
                return true;
            default:
                return true;
        }
    }

    public int fillBoxes() {
        i = Util.generteQuestion();
        binding.gameNumber1.setText(i.getDate()[0][0]);
        binding.gameNumber2.setText(i.getDate()[0][1]);
        binding.gameNumber3.setText(i.getDate()[0][2]);
        binding.gameNumber4.setText(i.getDate()[1][0]);
        binding.gameNumber5.setText(i.getDate()[1][1]);
        binding.gameNumber6.setText(i.getDate()[1][2]);
        binding.gameNumber7.setText(i.getDate()[2][0]);
        binding.gameNumber8.setText(i.getDate()[2][1]);
        binding.gameNumber9.setText(i.getDate()[2][2]);
        Log.wtf("@@", "_> " + i.getHiddenNumber());
        return
                i.getHiddenNumber();


    }

    private void Click() {
        if (player == null) {
            player = MediaPlayer.create(getBaseContext(), R.raw.button);
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    stopplayer();
                }
            });
        }
        player.start();
    }

    private void Wrong() {
        if (player == null) {
            player = MediaPlayer.create(getBaseContext(), R.raw.game);
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    stopplayer();
                }
            });
        }
        player.start();
    }

    private void Win() {
        if (player == null) {
            player = MediaPlayer.create(getBaseContext(), R.raw.win);
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    stopplayer();
                }
            });
        }
        player.start();
    }

    private void stopplayer() {
        if (player != null) {
            player.release();
            player = null;

        }
    }

    @Override
    public void onBackPressed() {
        if (time + 2000 > System.currentTimeMillis()) {
            super.onBackPressed();
        } else {
            Toast.makeText(GameActivity.this, "اظغط مرة اخرى للخروج", Toast.LENGTH_SHORT).show();
        }
        time = System.currentTimeMillis();
    }
}