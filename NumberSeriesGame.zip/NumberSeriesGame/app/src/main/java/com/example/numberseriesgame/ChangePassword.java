package com.example.numberseriesgame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ChangePassword extends AppCompatActivity {
    MediaPlayer player;
    EditText ChangePassword_et_NewPassword;
    Button ChangePassword_btn_Save;
    private static final String Key_password = "Password";
    SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        ChangePassword_et_NewPassword = findViewById(R.id.ChangePassword_et_NewPassword);
        ChangePassword_btn_Save = findViewById(R.id.ChangePassword_btn_Save);


        ChangePassword_btn_Save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Click();
                sharedPreferences = getSharedPreferences("Mypraf", MODE_PRIVATE);
                String newPassword = ChangePassword_et_NewPassword.getText().toString();

                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString(Key_password, newPassword);
                editor.apply();
                Click();

            }
        });


    }

    private void Click() {
        if (player == null) {
            player = MediaPlayer.create(getBaseContext(), R.raw.button);
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    stopplayer();
                }
            });
        }
        player.start();
    }



    private void stopplayer() {
        if (player != null) {
            player.release();
            player = null;

        }
    }
}

